<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>吉隆坡亚太彩</title>
    <meta name="keywords" content="吉隆坡亚太彩, 吉隆坡"/>
    <link rel="icon" href="img/icon/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE11"/>
    <meta name="format-detection" content="telephone=no">
    <script type="text/javascript" src="js/lib/jquery-1.11.3.js"></script>

    <link rel="stylesheet" href="./static/index.css">
    <link rel="icon" href="favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE11">
    <meta name="format-detection" content="telephone=no">
    <script type="text/javascript" src="./static/jquery-1.11.3.js"></script>
    <style>
        .STYLE2 {
            color: #A94D02;
            font-weight: bold;
            font-size: 40px;
        }
    </style>
</head>

<body>
<div class="bodybox">
    <!--头部-->
    <div id="headdivbox">
        <img style="width:100%;border-radius: 5px" src="/img/bp4.png"> <div class="headerbox">
            <div class="header">


                <a style="float:left" href="http://tempvsd.andsmind.com/"><img src="./img/logo2.png" alt=""></a>
                <ul style="background: #ed2842">
                    <li>
                        <a class="xy" href="http://tempvsd.andsmind.com/"
                        >首页</a>
                    </li> 

                    <li>
                        <a class="kj" href="http://tempvsd.andsmind.com/kaihistory">开奖记录</a>
                    </li>
                    <li>
                        <a class="yc" href="http://tempvsd.andsmind.com/yuctk">预测图库</a>
                    </li>
                    <li>
                        <a class="yc" href="http://tempvsd.andsmind.com/count_asis.php">号码过滤器</a>
                    </li>
                    <li>
                        <a class="js" href="http://tempvsd.andsmind.com/jieshao">彩票介绍</a>
                    </li>
                    <li>
                        <a class="ds"
                           href="http://tempvsd.andsmind.com/ds">公司董事</a>
                    </li>
                    <li>
                        <a  class="jj" href="http://tempvsd.andsmind.com/jj">奖金分配</a>
                    </li>
                    <li>
                        <a style="color: #ed2842; background: #fff; border-bottom: 3px solid #ed2842" class="rq" href="http://tempvsd.andsmind.com/rq.php">投注日期</a>
                    </li>
                    <li>
                        <a class="td" href="http://tempvsd.andsmind.com/tiangandizhi">天干地支</a>
                    </li>
                </ul>
            </div>
            <div class="notice-row">
                <div class="w clearfix pr">
                    <div class="title fl">
                        <marquee behavior="" direction="" onmouseenter="this.stop()" onmouseleave="this.start()">
                            <span>站内公告 :</span>
                            <font class="notifytxt" style="font-size: 30px" color="#FF0000"></font>
                        </marquee>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!--主体内容-->

    <div class="BigBox">
        <div class="outing">
            <table cellspacing="1" cellpadding="10" width="" bgcolor="#bcd22c" border="0">
                <tbody>
                <tr>
                    <td bgcolor="#ffffff">
                        <table style="TABLE-LAYOUT: fixed; WORD-BREAK: break-all" cellspacing="0" cellpadding="3"
                               width="100%" border="0">
                            <tbody>
                            <tr>
                                <td class="title" valign="bottom" align="middle" height="50">
                                    <div align="center"><span class="STYLE2">吉隆坡亚太彩彩投注日期</span></div>
                                </td>
                            </tr>
                            <tr>
                                <td valign="bottom" align="middle" height="30">
                                    <div align="center" class="STYLE6">来源：
                                        吉隆坡亚太彩发行中心
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <hr width="100%" color="#bcd22c" size="1">
                                </td>
                            </tr>
                            <tr>
                                <td class="zi14">
                                    <table cellspacing="0" bordercolordark="#ffffff" cellpadding="8" width="100%"
                                           align="center" bgcolor="#f2f3f5" bordercolorlight="#ff9900" border="1">
                                        <tbody>
                                        <tr>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <table cellspacing="0" cellpadding="0" width="100%" border="0">
                            <tbody>
                            <tr>
                                <td><h3 style="text-align: center">每晚20点30分<strong><font size="4">开奖</font></strong>
                                    </h3>
                                    <h3 style="text-align: center">
                                        <font size="4">&nbsp;&nbsp;</font>
                                        <iframe border="0" src="shijian2.htm"
                                                tppabs="http://tempvsd.andsmind.com/shijian2.htm" frameborder="0" width="686"
                                                scrolling="no" height="405" name="I1" target="_blank"></iframe>
                                    </h3>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    <!--尾部-->
    <div class="footer">
        <div id="fixedgoBack">

            <div id="modal" style="display: none;">
                <div id="win">
                    <div id="bar">
                        <span style="float:left">在线反馈</span>
                        <span class="bar_remove" style="float:right"></span>
                    </div>
                    <div class="hh">
                        欢迎对六合彩汇提出宝贵的建议或意见
                    </div>
                    <div class="content">
                        <label>称呼</label><input type="text" id="first_input"/>
                        <select name="" id="select_op">
                            <option value="1" class="option_index">电话</option>
                            <option value="2" class="option_index">邮箱</option>
                            <option value="3" class="option_index">QQ</option>
                            <option value="4" class="option_index">微信</option>
                        </select><input type="text" id="fanku_text"/>
                    </div>
                    <div class="div_down">
                        <textarea name="" rows="" cols="" id="advice" placeholder="请写下您宝贵的意见..."></textarea>
                    </div>
                    <div class="button_box">
                        <button id="btn_upload">提交</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer2">
            <p class="ptop">免责声明：本站内容仅作参考及交流，不进行任何现金交易行为。</p>
            <p style="display: inline">本网不承担由于内容的合法性所引起的一切争议和法律责任。</p>

        </div>
    </div>
    <script type="text/javascript" src="https://js.users.51.la/19291692.js"></script>

    <script type="text/javascript" src="js/getnotify.js"></script>
</div>

</body>

</html>
