/**
 * @description 命令配置项
 * @author wangfupeng
 */

export default {
    styleWithCSS: false, // 默认 false
}
