UEDITOR_CONFIG = window.UEDITOR_CONFIG || {};

var baidu = window.baidu || {};

window.baidu = baidu;

window.UE = baidu.editor = {
  plugins: {},
  commands: {},
  instants: {},
  I18N: {},
  _customizeUI: {},
  version: "1.5.0"
};
var dom = (UE.dom = {});
