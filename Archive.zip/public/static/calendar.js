(function (a, b) {
    if (typeof define === "function" && define.amd) {
        define("calendar", ["jquery"], b)
    } else {
        if (typeof exports === "object") {
            module.exports = b(require("jquery"))
        } else {
            b(a.jQuery)
        }
    }
}(this, function (f) {
    var n = {
            width: 219,
            height: 219,
            zIndex: 1,
            trigger: null,
            offset: [0, 1],
            customClass: "",
            view: "date",
            date: new Date(),
            format: "yyyy/mm/dd",
            startWeek: 0,
            weekArray: ["日", "一", "二", "三", "四", "五", "六"],
            selectedRang: null,
            data: null,
            label: "{d}\n{v}",
            prev: "&lt;",
            next: "&gt;",
            viewChange: f.noop,
            onSelected: function (C, D, E) {
            },
            onMouseenter: f.noop,
            onClose: f.noop
        }, u = "data-calendar-", d = "[" + u + "display-date]", A = "[" + u + "display-month]", i = "[" + u + "arrow-date]",
        j = "[" + u + "arrow-month]", y = u + "day", k = u + "month", w = "disabled", t = "markData",
        x = {date: "calendar-d", month: "calendar-m"}, s = "old", g = "new", v = "now", p = "selected",
        l = '<i class="dot"></i>', b = '{year}/<span class="m">{month}</span>',
        e = 'style="width:{w}px;height:{h}px;line-height:{h}px"', a = "<li " + e + ">{wk}</li>",
        m = "<li " + e + ' class="{class}" {action}>{value}</li>', h = "<li " + e + " " + k + ">{m}月</li>",
        r = ['<div class="calendar-inner">', '<div class="calendar-views">', '<div class="view view-date">', '<div class="calendar-hd">', '<a href="javascript:;" data-calendar-display-date class="calendar-display">', '{yyyy}/<span class="m">{mm}</span>', "</a>", '<div class="calendar-arrow">', '<span class="prev" title="上一月" data-calendar-arrow-date>{prev}</span>', '<span class="next" title="下一月" data-calendar-arrow-date>{next}</span>', "</div>", "</div>", '<div class="calendar-ct">', '<ol class="week">{week}</ol>', '<ul class="date-items"></ul>', "</div>", "</div>", '<div class="view view-month">', '<div class="calendar-hd">', '<a href="javascript:;" data-calendar-display-month class="calendar-display">{yyyy}</a>', '<div class="calendar-arrow">', '<span class="prev" title="上一年" data-calendar-arrow-month>{prev}</span>', '<span class="next" title="下一年" data-calendar-arrow-month>{next}</span>', "</div>", "</div>", '<ol class="calendar-ct month-items">{month}</ol>', "</div>", "</div>", "</div>", '<div class="calendar-label"><p>HelloWorld</p><i></i></div>'],
        c = Object.prototype.toString;

    function z(C) {
        return c.call(C) === "[object Date]"
    }

    function o(C) {
        return c.call(C) === "[object String]"
    }

    function B(C) {
        return C.getAttribute("class") || C.getAttribute("className")
    }

    String.prototype.repeat = function (C) {
        return this.replace(/\{\w+\}/g, function (D) {
            var E = D.replace(/\{|\}/g, "");
            return C[E] || ""
        })
    };
    String.prototype.toDate = function () {
        var E = new Date(), D = this.replace(/\d/g, "").charAt(0), C = this.split(D);
        E.setFullYear(C[0]);
        E.setMonth(C[1] - 1);
        E.setDate(C[2]);
        return E
    };
    Date.prototype.format = function (E) {
        var F = this.getFullYear(), C = this.getMonth() + 1, D = this.getDate();
        return E.replace("yyyy", F).replace("mm", C).replace("dd", D)
    };
    Date.prototype.isSame = function (F, C, E) {
        if (z(F)) {
            var D = F;
            F = D.getFullYear();
            C = D.getMonth() + 1;
            E = D.getDate()
        }
        return this.getFullYear() === F && this.getMonth() + 1 === C && this.getDate() === E
    };
    Date.prototype.add = function (C) {
        this.setDate(this.getDate() + C)
    };
    Date.prototype.minus = function (C) {
        this.setDate(this.getDate() - C)
    };
    Date.prototype.clearTime = function (C) {
        this.setHours(0);
        this.setSeconds(0);
        this.setMinutes(0);
        this.setMilliseconds(0);
        return this
    };
    Date.isLeap = function (C) {
        return (C % 100 !== 0 && C % 4 === 0) || (C % 400 === 0)
    };
    Date.getDaysNum = function (E, C) {
        var D = 31;
        switch (C) {
            case 2:
                D = this.isLeap(E) ? 29 : 28;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                D = 30;
                break
        }
        return D
    };
    Date.getSiblingsMonth = function (F, C, E) {
        var D = new Date(F, C - 1);
        D.setMonth(C - 1 + E);
        return {y: D.getFullYear(), m: D.getMonth() + 1}
    };
    Date.getPrevMonth = function (E, C, D) {
        return this.getSiblingsMonth(E, C, 0 - (D || 1))
    };
    Date.getNextMonth = function (E, C, D) {
        return this.getSiblingsMonth(E, C, D || 1)
    };
    Date.tryParse = function (C) {
        if (!C) {
            return C
        }
        return z(C) ? C : C.toDate()
    };

    function q(D, C) {
        this.$element = f(D);
        this.options = f.extend({}, f.fn.calendar.defaults, C);
        this.$element.addClass("calendar " + this.options.customClass);
        this.width = this.options.width;
        this.height = this.options.height;
        this.date = this.options.date;
        this.selectedRang = this.options.selectedRang;
        this.data = this.options.data;
        this.init()
    }

    q.prototype = {
        constructor: q, getDayAction: function (D) {
            var E = y;
            if (this.selectedRang) {
                var F = Date.tryParse(this.selectedRang[0]), C = Date.tryParse(this.selectedRang[1]);
                if ((F && D < F.clearTime()) || (C && D > C.clearTime())) {
                    E = w
                }
            }
            return E
        }, getDayData: function (D) {
            var E, H = this.data;
            if (H) {
                for (var F = 0, C = H.length; F < C; F++) {
                    var G = H[F];
                    if (D.isSame(G.date.toDate())) {
                        E = G.value
                    }
                }
            }
            return E
        }, getDayItem: function (J, D, I, G) {
            var C = this.date, L = new Date(J, D - 1, I), F = {w: this.width / 7, h: this.height / 7, value: I}, H, K;
            var E = C.isSame(J, D, I) ? p : "";
            if (G === 1) {
                F["class"] = s
            } else {
                if (G === 3) {
                    F["class"] = g
                } else {
                    F["class"] = ""
                }
            }
            if (C.isSame(J, D, I)) {
                F["class"] += " " + v
            }
            F.action = this.getDayAction(L);
            H = this.getDayData(L);
            K = f(m.repeat(F));
            if (H) {
                K.data(t, H);
                K.html(I + l)
            }
            return K
        }, getDaysHtml: function (G, P) {
            var H, T, R, F, J, I, L = this.date, K = f('<ol class="days"></ol>');
            if (z(G)) {
                H = G.getFullYear();
                T = G.getMonth() + 1
            } else {
                H = Number(G);
                T = Number(P)
            }
            R = new Date(H, T - 1, 1).getDay() || 7;
            I = R - this.options.startWeek;
            F = Date.getDaysNum(H, T);
            J = Date.getPrevMonth(H, T);
            prevDaysNum = Date.getDaysNum(H, J.m);
            nextM = Date.getNextMonth(H, T);
            var N = 1, C = 2, Q = 3, E = 0;
            for (var M = prevDaysNum - I + 1; M <= prevDaysNum; M++, E++) {
                K.append(this.getDayItem(J.y, J.m, M, N))
            }
            for (var S = 1; S <= F; S++, E++) {
                K.append(this.getDayItem(H, T, S, C))
            }
            for (var O = 1, D = 42 - E; O <= D; O++) {
                K.append(this.getDayItem(nextM.y, nextM.m, O, Q))
            }
            return f("<li></li>").width(this.options.width).append(K)
        }, getWeekHtml: function () {
            var H = [], E = this.options.weekArray, J = this.options.startWeek, C = E.length, D = this.width / 7,
                I = this.height / 7;
            for (var G = J; G < C; G++) {
                H.push(a.repeat({w: D, h: I, wk: E[G]}))
            }
            for (var F = 0; F < J; F++) {
                H.push(a.repeat({w: D, h: I, wk: E[F]}))
            }
            return H.join("")
        }, getMonthHtml: function () {
            var F = [], C = this.width / 4, E = this.height / 4, D = 1;
            for (; D < 13; D++) {
                F.push(h.repeat({w: C, h: E, m: D}))
            }
            return F.join("")
        }, setMonthAction: function (D) {
            var C = this.date.getMonth() + 1;
            this.$monthItems.children().removeClass(v);
            if (D === this.date.getFullYear()) {
                this.$monthItems.children().eq(C - 1).addClass(v)
            }
        }, fillStatic: function () {
            var C = {
                prev: this.options.prev,
                next: this.options.next,
                week: this.getWeekHtml(),
                month: this.getMonthHtml()
            };
            this.$element.html(r.join("").repeat(C))
        }, updateDisDate: function (D, C) {
            this.$disDate.html(b.repeat({year: D, month: C}))
        }, updateDisMonth: function (C) {
            this.$disMonth.html(C)
        }, fillDateItems: function (G, C) {
            var F = [Date.getPrevMonth(G, C), {y: G, m: C}, Date.getNextMonth(G, C)];
            this.$dateItems.html("");
            for (var E = 0; E < 3; E++) {
                var D = this.getDaysHtml(F[E].y, F[E].m);
                this.$dateItems.append(D)
            }
        }, hide: function (C, D, E) {
            this.$trigger.val(D.format(this.options.format));
            this.options.onClose.call(this, C, D, E);
            this.$element.hide()
        }, trigger: function () {
            this.$trigger = this.options.trigger instanceof f ? this.options.trigger : f(this.options.trigger);
            var F = this, E = F.$element, C = F.$trigger.offset(), D = F.options.offset;
            E.addClass("calendar-modal").css({
                left: (C.left + D[0]) + "px",
                top: (C.top + F.$trigger.outerHeight() + D[1]) + "px",
                zIndex: F.options.zIndex
            });
            F.$trigger.click(function () {
                E.show()
            });
            f(document).click(function (G) {
                if (F.$trigger[0] != G.target && !f.contains(E[0], G.target)) {
                    E.hide()
                }
            })
        }, render: function () {
            this.$week = this.$element.find(".week");
            this.$dateItems = this.$element.find(".date-items");
            this.$monthItems = this.$element.find(".month-items");
            this.$label = this.$element.find(".calendar-label");
            this.$disDate = this.$element.find(d);
            this.$disMonth = this.$element.find(A);
            var D = this.date.getFullYear(), C = this.date.getMonth() + 1;
            this.updateDisDate(D, C);
            this.updateMonthView(D);
            this.fillDateItems(D, C);
            this.options.trigger && this.trigger()
        }, setView: function (C) {
            this.$element.removeClass(x.date + " " + x.month).addClass(x[C]);
            this.view = C
        }, updateDateView: function (I, D, F, C) {
            D = D || this.date.getMonth() + 1;
            var H = this, G = this.$dateItems, E = {
                prev: function () {
                    var J = Date.getPrevMonth(I, D), K = Date.getPrevMonth(I, D, 2), L = H.getDaysHtml(K.y, K.m);
                    D = J.m;
                    I = J.y;
                    G.animate({marginLeft: 0}, 300, "swing", function () {
                        G.children(":last").remove();
                        G.prepend(L).css("margin-left", "-100%");
                        f.isFunction(C) && C.call(H)
                    })
                }, next: function () {
                    var K = Date.getNextMonth(I, D), J = Date.getNextMonth(I, D, 2), L = H.getDaysHtml(J.y, J.m);
                    D = K.m;
                    I = K.y;
                    G.animate({marginLeft: "-200%"}, 300, "swing", function () {
                        G.children(":first").remove();
                        G.append(L).css("margin-left", "-100%");
                        f.isFunction(C) && C.call(H)
                    })
                }
            };
            if (F) {
                E[F]()
            } else {
                this.fillDateItems(I, D)
            }
            this.updateDisDate(I, D);
            this.setView("date");
            return {y: I, m: D}
        }, updateMonthView: function (C) {
            this.updateDisMonth(C);
            this.setMonthAction(C);
            this.setView("month")
        }, getDisDateValue: function () {
            var D = this.$disDate.html().split("/"), E = Number(D[0]), C = Number(D[1].match(/\d{1,2}/)[0]);
            return [E, C]
        }, selectedDay: function (H, G) {
            var D = this.getDisDateValue(), I = D[0], C = D[1], F = function () {
                this.$dateItems.children(":eq(1)").find("[" + y + "]:not(." + g + ", ." + s + ")").removeClass(p).filter(function (J) {
                    return parseInt(this.innerHTML) === H
                }).addClass(p)
            };
            if (G) {
                var E = this.updateDateView(I, C, {old: "prev", "new": "next"}[G], F);
                I = E.y;
                C = E.m;
                this.options.viewChange("date", I, C)
            } else {
                F.call(this)
            }
            return new Date(I, C - 1, H)
        }, showLabel: function (G, D, E, H) {
            var I = this.$label;
            I.find("p").html(this.options.label.repeat({
                m: D,
                d: E.format(this.options.format),
                v: H
            }).replace(/\n/g, "<br>"));
            var C = I.outerWidth(), F = I.outerHeight();
            I.css({left: (G.pageX - C / 2) + "px", top: (G.pageY - F - 20) + "px"}).show()
        }, hasLabel: function () {
            if (this.options.label) {
                f("body").append(this.$label);
                return true
            }
            return false
        }, event: function () {
            var D = this, C = D.options.viewChange;
            D.$element.on("click", d, function () {
                var E = D.getDisDateValue();
                D.updateMonthView(E[0], E[1]);
                C("month", E[0], E[1])
            }).on("click", A, function () {
                var E = this.innerHTML;
                D.updateDateView(E);
                C("date", E)
            });
            D.$element.on("click", i, function () {
                var F = D.getDisDateValue(), G = B(this), I = F[0], E = F[1];
                var H = D.updateDateView(I, E, G, function () {
                    C("date", H.y, H.m)
                })
            }).on("click", j, function () {
                var F = Number(D.$disMonth.html()), E = B(this);
                F = E === "prev" ? F - 1 : F + 1;
                D.updateMonthView(F);
                C("month", F)
            });
            D.$element.on("click", "[" + y + "]", function () {
                var H = parseInt(this.innerHTML), E = B(this), G = /new|old/.test(E) ? E.match(/new|old/)[0] : "";
                var F = D.selectedDay(H, G);
                D.options.onSelected.call(this, "date", F, f(this).data(t));
                D.$trigger && D.hide("date", F, f(this).data(t))
            }).on("click", "[" + k + "]", function () {
                var F = Number(D.$disMonth.html()), E = parseInt(this.innerHTML);
                D.updateDateView(F, E);
                C("date", F, E);
                D.options.onSelected.call(this, "month", new Date(F, E - 1))
            });
            D.$element.on("mouseenter", "[" + y + "]", function (G) {
                var E = D.getDisDateValue(), F = new Date(E[0], E[1] - 1, parseInt(this.innerHTML));
                if (D.hasLabel && f(this).data(t)) {
                    f("body").append(D.$label);
                    D.showLabel(G, "date", F, f(this).data(t))
                }
                D.options.onMouseenter.call(this, "date", F, f(this).data(t))
            }).on("mouseleave", "[" + y + "]", function () {
                D.$label.hide()
            })
        }, resize: function () {
            var C = this.width, D = this.height, E = this.$element.find(".calendar-hd").outerHeight();
            this.$element.width(C).height(D + E).find(".calendar-inner, .view").css("width", C + "px");
            this.$element.find(".calendar-ct").width(C).height(D)
        }, init: function () {
            this.fillStatic();
            this.resize();
            this.render();
            this.view = this.options.view;
            this.setView(this.view);
            this.event()
        }, setData: function (C) {
            this.data = C;
            if (this.view === "date") {
                var D = this.getDisDateValue();
                this.fillDateItems(D[0], D[1])
            } else {
                if (this.view === "month") {
                    this.updateMonthView(this.$disMonth.html())
                }
            }
        }, methods: function (D, C) {
            if (c.call(this[D]) === "[object Function]") {
                return this[D].apply(this, C)
            }
        }
    };
    f.fn.calendar = function (D) {
        var F = this.data("calendar"), E, C = [].slice.call(arguments);
        if (!F) {
            return this.each(function () {
                return f(this).data("calendar", new q(this, D))
            })
        }
        if (o(D)) {
            E = D;
            C.shift();
            return F.methods(E, C)
        }
        return this
    };
    f.fn.calendar.defaults = n
}));