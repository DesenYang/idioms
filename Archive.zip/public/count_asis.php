<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>吉隆坡亚太彩</title>
    <meta name="keywords" content="吉隆坡亚太彩, 吉隆坡"/>
    <link rel="icon" href="img/icon/favicon.ico">
    <link rel="stylesheet" type="text/css" href="css/count_asis.css"/>
    <!--<script type="text/javascript" src="js/lib/jquery-1.7.2.min.js"></script>-->
    <script src="js/jquery-1.11.3.js?v=201812121716"></script>

    <link rel="stylesheet" href="./static/index.css">
</head>

<body>
<div class="bodybox">
    <!--头部-->
    <div id="headdivbox">
        <img style="width:100%;border-radius: 5px" src="/img/bp4.png"> <div class="headerbox">
            <div class="header">


                <a style="float:left" href="http://tempvsd.andsmind.com/"><img src="./img/logo2.png" alt=""></a>
                <ul style="background: #ed2842">
                    <li>
                        <a class="xy" href="http://tempvsd.andsmind.com/"
                        >首页</a> 
                    </li>

                    <li>
                        <a  class="kj" href="http://tempvsd.andsmind.com/kaihistory">开奖记录</a>
                    </li>
                    <li>
                        <a class="yc" href="http://tempvsd.andsmind.com/yuctk">预测图库</a>
                    </li>
                    <li>
                        <a  style="color: #ed2842; background: #fff; border-bottom: 3px solid #ed2842"  class="yc" href="http://tempvsd.andsmind.com/count_asis.php">号码过滤器</a>
                    </li>
                    <li>
                        <a class="js" href="http://tempvsd.andsmind.com/jieshao">彩票介绍</a>
                    </li>
                    <li>
                        <a class="ds"
                           href="http://tempvsd.andsmind.com/ds">公司董事</a>
                    </li>
                    <li>
                        <a  class="jj" href="http://tempvsd.andsmind.com/jj">奖金分配</a>
                    </li>
                    <li>
                        <a  class="rq" href="http://tempvsd.andsmind.com/rq.php">投注日期</a>
                    </li>
                    <li>
                        <a class="td" href="http://tempvsd.andsmind.com/tiangandizhi">天干地支</a>
                    </li>
                </ul>
            </div>
            <div class="notice-row">
                <div class="w clearfix pr">
                    <div class="title fl">
                        <marquee behavior="" direction="" onmouseenter="this.stop()" onmouseleave="this.start()">
                            <span>站内公告 :</span>
                            <font class="notifytxt" style="font-size: 30px" color="#FF0000"></font>
                        </marquee>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--主体内容-->

    <div class="BigBox">
        <div class="outing">
            <div class="inline">
                <div class="inline_count">
                    <h1>吉隆坡亚太彩在线统计器</h1>
                    <FORM style="PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px"
                          name=form2>
                        <INPUT title=01, type=hidden value=01 name=n_01>
                        <INPUT title=02, type=hidden value=02 name=n_02>
                        <INPUT title=03, type=hidden value=03 name=n_03>
                        <INPUT title=04, type=hidden value=04 name=n_04>
                        <INPUT title=05, type=hidden value=05 name=n_05>
                        <INPUT title=06, type=hidden value=06 name=n_06>
                        <INPUT title=07, type=hidden value=07 name=n_07>
                        <INPUT title=08, type=hidden value=08 name=n_08>
                        <INPUT title=09, type=hidden value=09 name=n_09>
                        <INPUT title=10, type=hidden value=10 name=n_10>
                        <INPUT title=11, type=hidden value=11 name=n_11>
                        <INPUT title=12, type=hidden value=12 name=n_12>
                        <INPUT title=13, type=hidden value=13 name=n_13>
                        <INPUT title=14, type=hidden value=14 name=n_14>
                        <INPUT title=15, type=hidden value=15 name=n_15>
                        <INPUT title=16, type=hidden value=16 name=n_16>
                        <INPUT title=17, type=hidden value=17 name=n_17>
                        <INPUT title=18, type=hidden value=18 name=n_18>
                        <INPUT title=19, type=hidden value=19 name=n_19>
                        <INPUT title=20, type=hidden value=20 name=n_20>
                        <INPUT title=21, type=hidden value=21 name=n_21>
                        <INPUT title=22, type=hidden value=22 name=n_22>
                        <INPUT title=23, type=hidden value=23 name=n_23>
                        <INPUT title=24, type=hidden value=24 name=n_24>
                        <INPUT title=25, type=hidden value=25 name=n_25>
                        <INPUT title=26, type=hidden value=26 name=n_26>
                        <INPUT title=27, type=hidden value=27 name=n_27>
                        <INPUT title=28, type=hidden value=28 name=n_28>
                        <INPUT title=29, type=hidden value=29 name=n_29>
                        <INPUT title=30, type=hidden value=30 name=n_30>
                        <INPUT title=31, type=hidden value=31 name=n_31>
                        <INPUT title=32, type=hidden value=32 name=n_32>
                        <INPUT title=33, type=hidden value=33 name=n_33>
                        <INPUT title=34, type=hidden value=34 name=n_34>
                        <INPUT title=35, type=hidden value=35 name=n_35>
                        <INPUT title=36, type=hidden value=36 name=n_36>
                        <INPUT title=37, type=hidden value=37 name=n_37>
                        <INPUT title=38, type=hidden value=38 name=n_38>
                        <INPUT title=39, type=hidden value=39 name=n_39>
                        <INPUT title=40, type=hidden value=40 name=n_40>
                        <INPUT title=41, type=hidden value=41 name=n_41>
                        <INPUT title=42, type=hidden value=42 name=n_42>
                        <INPUT title=43, type=hidden value=43 name=n_43>
                        <INPUT title=44, type=hidden value=44 name=n_44>
                        <INPUT title=45, type=hidden value=45 name=n_45>
                        <INPUT title=46, type=hidden value=46 name=n_46>
                        <INPUT title=47, type=hidden value=47 name=n_47>
                        <INPUT title=48, type=hidden value=48 name=n_48>
                        <INPUT title=49, type=hidden value=49 name=n_49>
                        <INPUT title=1, type=hidden value=1 name=n_1>
                        <INPUT title=2, type=hidden value=2 name=n_2>
                        <INPUT title=3, type=hidden value=3 name=n_3>
                        <INPUT title=4, type=hidden value=4 name=n_4>
                        <INPUT title=5, type=hidden value=5 name=n_5>
                        <INPUT title=6, type=hidden value=6 name=n_6>
                        <INPUT title=7, type=hidden value=7 name=n_7>
                        <INPUT title=8, type=hidden value=8 name=n_8>
                        <INPUT title=9, type=hidden value=9 name=n_9>
                    </FORM>

                    <form name="form">

                        <div class="inline_countbox">
                            <div class="inline_countl">
                                <ul class="ullist_top">
                                    <li class="title">两面 :</li>

                                    <input title="01,03,05,07,09,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41,43,45,47,49,"
                                           onClick="addText('单,');" type="button" value="单" name="n_单">
                                    <input title="25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,"
                                           onClick="addText('大,');" type="button" value="大" name="n_大">
                                    <input title="01,03,05,07,09,10,12,14,16,18,21,23,25,27,29,30,32,34,36,38,41,43,45,47,49,"
                                           onClick="addText('合单,');" type="button" value="合单" name="n_合单">
                                    <input title="07,08,09,16,17,18,19,25,26,27,28,29,34,35,36,37,38,39,43,44,45,46,47,48,49,"
                                           onClick="addText('合大,');" type="button" value="合大" name="n_合大">
                                    <input title="05,06,07,08,09,15,16,17,18,19,25,26,27,28,29,35,36,37,38,39,45,46,47,48,49,"
                                           onClick="addText('尾大,');" type="button" value="尾大" name="n_尾大">
                                    <input title="25,27,29,31,33,35,37,39,41,43,45,47,49," onClick="addText('大单,');"
                                           type="button" value="大单" name="n_大单">
                                    <input title="26,28,30,32,34,36,38,40,42,44,46,48," onClick="addText('大双,');"
                                           type="button" value="大双" name="n_大双">
                                    <input title="02,04,06,08,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,"
                                           onClick="addText('双,');" type="button" value="双" name="n_双">
                                    <input title="01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,"
                                           onClick="addText('小,');" type="button" value="小" name="n_小">
                                    <input title="02,04,06,08,11,13,15,17,19,20,22,24,26,28,31,33,35,37,39,40,42,44,46,48,"
                                           onClick="addText('合双,');" type="button" value="合双" name="n_合双">
                                    <input title="01,02,03,04,05,06,10,11,12,13,14,15,20,21,22,23,24,30,31,32,33,40,41,42,"
                                           onClick="addText('合小,');" type="button" value="合小" name="n_合小">
                                    <input title="01,02,03,04,10,11,12,13,14,20,21,22,23,24,30,31,32,33,34,40,41,42,43,44,"
                                           onClick="addText('尾小,');" type="button" value="尾小" name="n_尾小">
                                    <input title="01,03,05,07,09,11,13,15,17,19,21,23," onClick="addText('小单,');"
                                           type="button" value="小单" name="n_小单">
                                    <input title="02,04,06,08,10,12,14,16,18,20,22,24," onClick="addText('小双,');"
                                           type="button" value="小双" name="n_小双">

                                </ul>
                                <ul>
                                    <li class="title">半波 :</li>
                                    <input title="01,07,13,19,23,29,35,45," onClick="addText('红单,');" type="button"
                                           value="红单" name="n_红单">
                                    <input title="05,11,17,21,27,33,39,43,49," onClick="addText('绿单,');" type="button"
                                           value="绿单" name="n_绿单">
                                    <input title="03,09,15,25,31,37,41,47," onClick="addText('蓝单,');" type="button"
                                           value="蓝单" name="n_蓝单">
                                    <input title="02,08,12,18,24,30,34,40,46," onClick="addText('红双,');" type="button"
                                           value="红双" name="n_红双">
                                    <input title="06,16,22,28,32,38,44," onClick="addText('绿双,');" type="button"
                                           value="绿双" name="n_绿双">
                                    <input title="04,10,14,20,26,36,42,48," onClick="addText('蓝双,');" type="button"
                                           value="蓝双" name="n_蓝双">

                                    <input title="29,30,34,35,40,45,46," onClick="addText('红大,');" type="button"
                                           value="红大" name="n_红大">
                                    <input title="01,02,07,08,12,13,18,19,23,24," onClick="addText('红小,');"
                                           type="button" value="红小" name="n_红小">

                                    <input title="25,26,31,36,37,41,42,47,48," onClick="addText('蓝大,');" type="button"
                                           value="蓝大" name="n_蓝大">
                                    <input title="03,04,09,10,14,15,20," onClick="addText('蓝小,');" type="button"
                                           value="蓝小" name="n_蓝小">

                                    <input title="27,28,32,33,38,39,43,44,49," onClick="addText('绿大,');" type="button"
                                           value="蓝小" name="n_绿大">
                                    <input title="05,06,11,16,17,21,22,27," onClick="addText('绿小,');" type="button"
                                           value="绿小" name="n_绿小">

                                    <input title="29,35,45," onClick="addText('红大单,');" type="button" value="红大单"
                                           name="n_红大单">
                                    <input title="24,30,34,40,46," onClick="addText('红大双,');" type="button" value="红大双"
                                           name="n_红大双">
                                    <input title="01,07,13,19,23," onClick="addText('红小单,');" type="button" value="红小单"
                                           name="n_红小单">
                                    <input style="margin-left:63px;" title="02,08,12,18,24," onClick="addText('红小双,');"
                                           type="button" value="红小双" name="n_红小双">

                                    <input title="25,31,37,41,47," onClick="addText('蓝大单,');" type="button" value="蓝大单"
                                           name="n_蓝大单">
                                    <input title="26,36,42,48," onClick="addText('蓝大双,');" type="button" value="蓝大双"
                                           name="n_蓝大双">
                                    <input title="03,09,15," onClick="addText('蓝小单,');" type="button" value="蓝小单"
                                           name="n_蓝小单">
                                    <input title="04,10,14,20," onClick="addText('蓝小双,');" type="button" value="蓝小双"
                                           name="n_蓝小双">

                                    <input title="27,33,39,43,49," onClick="addText('绿大单,');" type="button" value="绿大单"
                                           name="n_绿大单">
                                    <input title="28,32,38,44," onClick="addText('绿大双,');" type="button" value="绿大双"
                                           name="n_绿大双">
                                    <input title="05,11,17,21," onClick="addText('绿小单,');" type="button" value="绿小单"
                                           name="n_绿小单">
                                    <input title="06,16,22," onClick="addText('绿小双,');" type="button" value="绿小双"
                                           name="n_绿小双">

                                </ul>
                                <ul class="toushuUl">
                                    <li class="title">头数 :</li>
                                    <input title="01,02,03,04,05,06,07,08,09," onClick="addText('0头,');" type="button"
                                           value="0头" name="n_0头">
                                    <input title="10,11,12,13,14,15,16,17,18,19," onClick="addText('1头,');"
                                           type="button" value="1头" name="n_1头">
                                    <input title="20,21,22,23,24,25,26,27,28,29," onClick="addText('2头,');"
                                           type="button" value="2头" name="n_2头">
                                    <input title="30,31,32,33,34,35,36,37,38,39," onClick="addText('3头,');"
                                           type="button" value="3头" name="n_3头">
                                    <input title="40,41,42,43,44,45,46,47,48,49," onClick="addText('4头,');"
                                           type="button" value="4头" name="n_4头">
                                    <input title="01,03,05,07,09," onClick="addText('0头单,');" type="button" value="0头单"
                                           name="n_0头单">
                                    <input title="11,13,15,17,19," onClick="addText('1头单,');" type="button" value="1头单"
                                           name="n_1头单">
                                    <input title="21,23,25,27,29," onClick="addText('2头单,');" type="button" value="2头单"
                                           name="n_2头单">
                                    <input title="31,33,35,37,39," onClick="addText('3头单,');" type="button" value="3头单"
                                           name="n_3头单">
                                    <input title="41,43,45,47,49," onClick="addText('4头单,');" type="button" value="4头单"
                                           name="n_4头单">
                                    <input title="02,04,06,08," onClick="addText('0头双,');" type="button" value="0头双"
                                           name="n_0头双">
                                    <input title="10,12,14,16,18," onClick="addText('1头双,');" type="button" value="1头双"
                                           name="n_1头双">
                                    <input title="20,22,24,26,28," onClick="addText('2头双,');" type="button" value="2头双"
                                           name="n_2头双">
                                    <input title="30,32,34,36,38," onClick="addText('3头双,');" type="button" value="3头双"
                                           name="n_3头双">
                                    <input title="40,42,44,46,48," onClick="addText('4头双,');" type="button" value="4头双"
                                           name="n_4头双">

                                </ul>
                                <ul>
                                    <li class="title">尾数 :</li>
                                    <input title="10,20,30,40," onClick="addText('0尾,');" type="button" value="0尾"
                                           name="n_0尾">
                                    <input title="01,11,21,31,41," onClick="addText('1尾,');" type="button" value="1尾"
                                           name="n_1尾">
                                    <input title="02,12,22,32,42," onClick="addText('2尾,');" type="button" value="2尾"
                                           name="n_2尾">
                                    <input title="03,13,23,33,43," onClick="addText('3尾,');" type="button" value="3尾"
                                           name="n_3尾">
                                    <input title="04,14,24,34,44," onClick="addText('4尾,');" type="button" value="4尾"
                                           name="n_4尾">

                                    <input title="05,15,25,35,45," onClick="addText('5尾,');" type="button" value="5尾"
                                           name="n_5尾">
                                    <input title="06,16,26,36,46," onClick="addText('6尾,');" type="button" value="6尾"
                                           name="n_6尾">
                                    <input title="07,17,27,37,47," onClick="addText('7尾,');" type="button" value="7尾"
                                           name="n_7尾">
                                    <input title="08,18,28,38,48," onClick="addText('8尾,');" type="button" value="8尾"
                                           name="n_8尾">
                                    <input title="09,19,29,39,49," onClick="addText('9尾,');" type="button" value="9尾"
                                           name="n_9尾">

                                </ul>
                                <ul>
                                    <li class="title">合数 :</li>
                                    <input title="01,10," onClick="addText('1合,');" type="button" value="1合"
                                           name="n_1合">
                                    <input title="02,11,20," onClick="addText('2合,');" type="button" value="2合"
                                           name="n_2合">
                                    <input title="03,12,21,30," onClick="addText('3合,');" type="button" value="3合"
                                           name="n_3合">
                                    <input title="04,13,22,31,40," onClick="addText('4合,');" type="button" value="4合"
                                           name="n_4合">
                                    <input title="05,14,23,32,41," onClick="addText('5合,');" type="button" value="5合"
                                           name="n_5合">
                                    <input title="06,15,24,33,42," onClick="addText('6合,');" type="button" value="6合"
                                           name="n_6合">
                                    <input title="07,16,25,34,43," onClick="addText('7合,');" type="button" value="7合"
                                           name="n_7合">

                                    <input title="08,17,26,35,44," onClick="addText('8合,');" type="button" value="8合"
                                           name="n_8合">
                                    <input title="09,18,27,36,45," onClick="addText('9合,');" type="button" value="9合"
                                           name="n_9合">
                                    <input title="19,28,37,46," onClick="addText('10合,');" type="button" value="10合"
                                           name="n_10合">
                                    <input title="29,38,47," onClick="addText('11合,');" type="button" value="11合"
                                           name="n_11合">
                                    <input title="39,48," onClick="addText('12合,');" type="button" value="12合"
                                           name="n_12合">
                                    <input title="49," onClick="addText('13合,');" type="button" value="13合"
                                           name="n_13合">

                                    <input title="19,28,37,46," onClick="addText('0合尾,');" type="button" value="0合尾"
                                           name="n_0合尾">
                                    <input title="01,10,29,38,47," onClick="addText('1合尾,');" type="button" value="1合尾"
                                           name="n_1合尾">
                                    <input title="02,11,20,39,48," onClick="addText('2合尾,');" type="button" value="2合尾"
                                           name="n_2合尾">
                                    <input style="margin-left:63px;" title="03,12,21,30,49," onClick="addText('3合尾,');"
                                           type="button" value="3合尾" name="n_3合尾">
                                    <input title="04,13,22,31,40," onClick="addText('4合尾,');" type="button" value="4合尾"
                                           name="n_4合尾">
                                    <input title="05,14,23,32,41," onClick="addText('5合尾,');" type="button" value="5合尾"
                                           name="n_5合尾">
                                    <input title="06,15,24,33,42," onClick="addText('6合尾,');" type="button" value="6合尾"
                                           name="n_6合尾">
                                    <input title="07,16,25,34,43," onClick="addText('7合尾,');" type="button" value="7合尾"
                                           name="n_7合尾">
                                    <input title="08,17,26,35,44," onClick="addText('8合尾,');" type="button" value="8合尾"
                                           name="n_8合尾">
                                    <input title="09,18,27,36,45," onClick="addText('9合尾,');" type="button" value="9合尾"
                                           name="n_9合尾">

                                </ul>
                                <ul>
                                    <li class="title">余数 :</li>
                                    <input title="03,06,09,12,15,18,21,24,27,30,33,36,39,42,45,48,"
                                           onClick="addText('3余零,');" type="button" value="3余0" name="n_3余零">
                                    <input title="01,04,07,10,13,16,19,22,25,28,31,34,37,40,43,46,49,"
                                           onClick="addText('3余一,');" type="button" value="3余1" name="n_3余一">
                                    <input title="02,05,08,11,14,17,20,23,26,29,32,35,38,41,44,47,"
                                           onClick="addText('3余二,');" type="button" value="3余2" name="n_3余二">
                                    <input title="04,08,12,16,20,24,28,32,36,40,44,48," onClick="addText('4余零,');"
                                           type="button" value="4余0" name="n_4余零">
                                    <input title="01,05,09,13,17,21,25,29,33,37,41,45,49," onClick="addText('4余一,');"
                                           type="button" value="4余1" name="n_4余一">
                                    <input title="02,06,10,14,18,22,26,30,34,38,42,46," onClick="addText('4余二,');"
                                           type="button" value="4余2" name="n_4余二">
                                    <input title="03,07,11,15,19,23,27,31,35,39,43,47," onClick="addText('4余三,');"
                                           type="button" value="4余3" name="n_4余三">
                                    <input title="05,10,15,20,25,30,35,40,45," onClick="addText('5余零,');" type="button"
                                           value="5余0" name="n_5余零">
                                    <input title="01,06,11,16,21,26,31,36,41,46," onClick="addText('5余一,');"
                                           type="button" value="5余1" name="n_5余一">
                                    <input title="02,07,12,17,22,27,32,37,42,47," onClick="addText('5余二,');"
                                           type="button" value="5余2" name="n_5余二">
                                    <input title="03,08,13,18,23,28,33,38,43,48," onClick="addText('5余三,');"
                                           type="button" value="5余3" name="n_5余三">
                                    <input title="04,09,14,19,24,29,34,39,44,49," onClick="addText('5余四,');"
                                           type="button" value="5余4" name="n_5余四">
                                    <input title="06,12,18,24,30,36,42,48," onClick="addText('6余零,');" type="button"
                                           value="6余0" name="n_6余零">
                                    <input title="01,07,13,19,25,31,37,43,49," onClick="addText('6余一,');" type="button"
                                           value="6余1" name="n_6余一">
                                    <input title="02,08,14,20,26,32,38,44," onClick="addText('6余二,');" type="button"
                                           value="6余2" name="n_6余二">
                                    <input style="margin-left:63px;" title="03,09,15,21,27,33,39,45,"
                                           onClick="addText('6余三,');" type="button" value="6余3" name="n_6余三">
                                    <input title="04,10,16,22,28,34,40,46," onClick="addText('6余四,');" type="button"
                                           value="6余4" name="n_6余四">
                                    <input title="05,11,17,23,29,35,41,47," onClick="addText('6余五,');" type="button"
                                           value="6余5" name="n_6余五">
                                    <input title="07,14,21,28,35,42,49," onClick="addText('7余零,');" type="button"
                                           value="7余0" name="n_7余零">
                                    <input title="01,08,15,22,29,36,43," onClick="addText('7余一,');" type="button"
                                           value="7余1" name="n_7余一">
                                    <input title="02,09,16,23,30,37,44," onClick="addText('7余二,');" type="button"
                                           value="7余2" name="n_7余二">
                                    <input title="03,10,17,24,31,38,45," onClick="addText('7余三,');" type="button"
                                           value="7余3" name="n_7余三">
                                    <input title="04,11,18,25,32,39,46," onClick="addText('7余四,');" type="button"
                                           value="7余4" name="n_7余四">
                                    <input title="05,12,19,26,33,40,47," onClick="addText('7余五,');" type="button"
                                           value="7余5" name="n_7余五">
                                    <input title="06,13,20,27,34,41,48," onClick="addText('7余六,');" type="button"
                                           value="7余6" name="n_7余六">

                                </ul>
                            </div>

                        </div>

                        <div class="haomaduan">
                            <div class="haomaduanl">
                                <ul>
                                    <input title="01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,25,26,27,28,"
                                           onClick="addText('楼上码,');" type="button" value="楼上码" name="n_楼上码">
                                    <input title="01,02,03,04,05,06,07,08,17,18,19,20,21,22,23,24,33,34,35,36,37,38,39,40,"
                                           onClick="addText('前落码,');" type="button" value="前落码" name="n_前落码">
                                    <input title="01,02,03,04,08,09,10,11,15,16,17,18,22,23,24,29,30,31,36,37,38,43,44,45,"
                                           onClick="addText('左边码,');" type="button" value="左边码" name="n_左边码">
                                    <input title="09,10,11,12,13,16,17,18,19,20,23,24,25,26,27,30,31,32,33,34,37,38,39,40,41,"
                                           onClick="addText('内围码,');" type="button" value="内围码" name="n_内围码">
                                    <input title="13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,"
                                           onClick="addText('中数,');" type="button" value="中数" name="n_中数">

                                    <input title="22,23,24,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,"
                                           onClick="addText('楼下码,');" type="button" value="楼下码" name="n_楼下码">
                                    <input title="09,10,11,12,13,14,15,16,25,26,27,28,29,30,31,32,41,42,43,44,45,46,47,48,49,"
                                           onClick="addText('后落码,');" type="button" value="后落码" name="n_后落码">
                                    <input title="05,06,07,12,13,14,19,20,21,25,26,27,28,32,33,34,35,39,40,41,42,46,47,48,49,"
                                           onClick="addText('右边码,');" type="button" value="右边码" name="n_右边码">
                                    <input title="01,02,03,04,05,06,07,08,14,15,21,22,28,29,35,36,42,43,44,45,46,47,48,49,"
                                           onClick="addText('外围码,');" type="button" value="外围码" name="n_外围码">
                                    <input title="01,02,03,04,05,06,07,08,09,10,11,12,38,39,40,41,42,43,44,45,46,47,48,49,"
                                           onClick="addText('边数,');" type="button" value="边数" name="n_边数">

                                </ul>
                            </div>
                            <div class="haomaduanr">
                                输入号码段数 :
                                <input id="id_hao_from" style="WIDTH: 30px" maxlength="2"
                                       name="hao_from">&nbsp;至&nbsp;<input id="id_hao_to" style="WIDTH: 30px"
                                                                           maxlength="2" name="hao_to">&nbsp;<input
                                        style="WIDTH: 50px;height:24px;border:0;background:#727481;color:#fff;margin:0 5px"
                                        onClick="addteduan();" type="button" value="插入">(限:01-49)

                            </div>
                        </div>
                        <!--统计号码区-->
                        <div class="tjhmq">
                            <textarea id="inputtxt" name="inputtxt" wrap="PHYSICAL" cols=""></textarea>
                            <div class="submitBtn">
                                <!--<span >统计号码</span>-->
                                <input class="countCode" onClick="countma();" type="button" value="统计号码">
                                <input class="clear" onClick="resetinput();" type="button" value=" 清 空 ">

                                <!--<span>清空</span>-->
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="box">
                <div style="background-color: white" class="listhead">

                    <div class="result">
                        <h1>统计结果</h1>
                        <p id="resultstxt"  name="resultstxt" wrap="off" cols=""></p>

                    </div>
                </div>
            </div>
        </div>
        <!--统计结果-->

    </div>
</div>
<div class="footer">

    <div class="footer2">
        <p class="ptop">免责声明：本站内容仅作参考及交流，不进行任何现金交易行为。</p>
        <p style="display: inline">本网不承担由于内容的合法性所引起的一切争议和法律责任。</p>

    </div>
</div>
<script type="text/javascript" src="https://js.users.51.la/19291692.js"></script>

</div>
<script src="js/config.js?v=201812121716"></script>
<script type="text/javascript" src="js/public_hf.js?v=201812121716"></script>
<!--<script src="js/count_asis/base.js" + "sb=10403" type="text/javascript"></script>-->
<script src="js/countonline.js"></script>
<script type="text/javascript">
    $(function () {
        var setTime = setTimeout(function () {
            if ($(".hm").length != 0) {
                clearTimeout(setTime)
            }
            $(".hm").css({
                "color": "#fff",
                "background": "#ED2842"
            });
            $(".tb").css({
                "color": "#333",
                "background": "#fff"
            });

        }, 100)
    })
</script>

<script type="text/javascript" src="js/getnotify.js"></script>
</body>

</html>