<?php


namespace app\config;

return [
    'tpl_replacestring' => [
        'STATIC'=>'/static',
    ],
];